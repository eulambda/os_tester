#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

void print_frees(int lvl)
{
	static int nr_frees = -1;
	static int prev_nr_frees = -1;
	if (nr_frees == -1)
		nr_frees = frees();
	if (lvl == -1)
		return;
	prev_nr_frees = nr_frees;
	nr_frees = frees();
	printf(1, "delta frees at level %d: %d\n", lvl, nr_frees - prev_nr_frees);
}
void step_into(int lvl)
{
	int buff[504] = {0};
	print_frees(lvl);
	printf(0, "p=%p\n", buff);
	step_into(lvl + 1);
}
void trigger_stack_overflow()
{
	int buff[12 * 4 + 4 * 16 * 15] = {0};
	print_frees(0);
	printf(0, "p=%p\n", buff);
	step_into(1);
}
int main(void)
{
	print_frees(-1);
	trigger_stack_overflow();
}
