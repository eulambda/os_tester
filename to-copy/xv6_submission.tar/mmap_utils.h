#include "mmap_constants.h"

struct mmap_area
{
    int user_nr;
    int len;
    int len_raw;
    int offset;
    int flags;
    void *ptr;
    struct file *file;
};

struct mmap_table_local
{
    struct mmap_area *areas[MAP_AREA_NR_PER_PROCESS];
};
