#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"
#include "traps.h"
#include "memlayout.h"
#include "fcntl.h"
#include "mmap_constants.h"

void print_frees(char *desc)
{
	static int nr_frees = -1;
	static int prev_nr_frees = -1;
	if (nr_frees == -1)
		nr_frees = frees();
	if (!desc)
		return;
	prev_nr_frees = nr_frees;
	nr_frees = frees();
	printf(1, "delta frees after %s: %d\n", desc, nr_frees - prev_nr_frees);
}

int main(void)
{
	int fd_long = open("long.testdata", O_RDWR);
	int fd_short = open("short.testdata", O_RDWR);
	print_frees(0);
	char *start = (char *)mmap(fd_long, 1, 8192, MAP_PROT_READ | MAP_PROT_WRITE);
	print_frees("mmap");
	char next_char = '0' + (start[0] - '0' + 1) % 10;
	start[0] = next_char;
	print_frees("the first touch");
	printf(1, "* 1.1\n");
	printf(1, " addr=%p\n", start);
	printf(1, " content=%s\n", start);
	print_frees("print");
	printf(1, " unmapped?=%d\n", munmap(start, 8192) == 0);
	print_frees("unmap");

	start = (char *)mmap(fd_short, 1, 8192, MAP_PROT_READ | MAP_PROT_WRITE);
	print_frees("another map");
	printf(1, "* 1.2\n");
	printf(1, " addr=%p\n", start);
	printf(1, " content=%s\n", start);
	next_char = '0' + (start[0] - '0' + 1) % 10;
	start[0] = next_char;
	print_frees("print");
	printf(1, " unmapped?=%d\n", munmap(start, 8192) == 0);
	print_frees("unmap");

	start = (char *)mmap(fd_long, 1, 8192, MAP_PROT_READ);
	printf(1, "* 2.1\n");
	printf(1, " addr=%p\n", start);
	printf(1, " content=%s\n", start);
	printf(1, " unmapped?=%d\n", munmap(start, 8192) == 0);

	start = (char *)mmap(fd_short, 1, 8192, MAP_PROT_READ);
	printf(1, "* 2.2\n");
	printf(1, " addr=%p\n", start);
	printf(1, " content=%s\n", start);
	// printf(1, " unmapped?=%d\n", munmap(start, 8192) == 0);

	exit();
}
