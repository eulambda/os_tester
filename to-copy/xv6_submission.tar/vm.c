#include "param.h"
#include "types.h"
#include "defs.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "elf.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "mmap_utils.h"

extern char data[]; // defined by kernel.ld
pde_t *kpgdir;      // for use in scheduler()

struct mmap_table
{
  struct spinlock lock;
  struct mmap_area areas[MAP_AREA_NR_PER_SYSTEM];
} mmap_table;

// Set up CPU's kernel segment descriptors.
// Run once on entry on each CPU.
void seginit(void)
{
  struct cpu *c;

  // Map "logical" addresses to virtual addresses using identity map.
  // Cannot share a CODE descriptor for both kernel and user
  // because it would have to have DPL_USR, but the CPU forbids
  // an interrupt from CPL=0 to DPL=3.
  c = &cpus[cpuid()];
  c->gdt[SEG_KCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, 0);
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
  c->gdt[SEG_UCODE] = SEG(STA_X | STA_R, 0, 0xffffffff, DPL_USER);
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
  lgdt(c->gdt, sizeof(c->gdt));
}

// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
  if (*pde & PTE_P)
  {
    pgtab = (pte_t *)P2V(PTE_ADDR(*pde));
  }
  else
  {
    if (!alloc || (pgtab = (pte_t *)kalloc()) == 0)
      return 0;
    // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
  char *a, *last;
  pte_t *pte;

  a = (char *)PGROUNDDOWN((uint)va);
  last = (char *)PGROUNDDOWN(((uint)va) + size - 1);
  for (;;)
  {
    if ((pte = walkpgdir(pgdir, a, 1)) == 0)
      return -1;
    if (*pte & PTE_P)
      panic("remap");
    *pte = pa | perm | PTE_P;
    if (a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// There is one page table per process, plus one that's used when
// a CPU is not running any process (kpgdir). The kernel uses the
// current process's page table during system calls and interrupts;
// page protection bits prevent user code from using the kernel's
// mappings.
//
// setupkvm() and exec() set up every page table like this:
//
//   0..KERNBASE: user memory (text+data+stack+heap), mapped to
//                phys memory allocated by the kernel
//   KERNBASE..KERNBASE+EXTMEM: mapped to 0..EXTMEM (for I/O space)
//   KERNBASE+EXTMEM..data: mapped to EXTMEM..V2P(data)
//                for the kernel's instructions and r/o data
//   data..KERNBASE+PHYSTOP: mapped to V2P(data)..PHYSTOP,
//                                  rw data + free physical memory
//   0xfe000000..0: mapped direct (devices such as ioapic)
//
// The kernel allocates physical memory for its heap and for user memory
// between V2P(end) and the end of physical memory (PHYSTOP)
// (directly addressable from end..P2V(PHYSTOP)).

// This table defines the kernel's mappings, which are present in
// every process's page table.
static struct kmap
{
  void *virt;
  uint phys_start;
  uint phys_end;
  int perm;
} kmap[] = {
    {(void *)KERNBASE, 0, EXTMEM, PTE_W},            // I/O space
    {(void *)KERNLINK, V2P(KERNLINK), V2P(data), 0}, // kern text+rodata
    {(void *)data, V2P(data), PHYSTOP, PTE_W},       // kern data+memory
    {(void *)DEVSPACE, DEVSPACE, 0, PTE_W},          // more devices
};

// Set up kernel part of a page table.
pde_t *
setupkvm(void)
{
  pde_t *pgdir;
  struct kmap *k;

  if ((pgdir = (pde_t *)kalloc()) == 0)
    return 0;
  memset(pgdir, 0, PGSIZE);
  if (P2V(PHYSTOP) > (void *)DEVSPACE)
    panic("PHYSTOP too high");
  for (k = kmap; k < &kmap[NELEM(kmap)]; k++)
    if (mappages(pgdir, k->virt, k->phys_end - k->phys_start,
                 (uint)k->phys_start, k->perm) < 0)
    {
      freevm(pgdir);
      return 0;
    }
  return pgdir;
}

// Allocate one page table for the machine for the kernel address
// space for scheduler processes.
void kvmalloc(void)
{
  kpgdir = setupkvm();
  switchkvm();
}

// Switch h/w page table register to the kernel-only page table,
// for when no process is running.
void switchkvm(void)
{
  lcr3(V2P(kpgdir)); // switch to the kernel page table
}

// Switch TSS and h/w page table to correspond to process p.
void switchuvm(struct proc *p)
{
  if (p == 0)
    panic("switchuvm: no process");
  if (p->kstack == 0)
    panic("switchuvm: no kstack");
  if (p->pgdir == 0)
    panic("switchuvm: no pgdir");

  pushcli();
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
                                sizeof(mycpu()->ts) - 1, 0);
  mycpu()->gdt[SEG_TSS].s = 0;
  mycpu()->ts.ss0 = SEG_KDATA << 3;
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
  // setting IOPL=0 in eflags *and* iomb beyond the tss segment limit
  // forbids I/O instructions (e.g., inb and outb) from user space
  mycpu()->ts.iomb = (ushort)0xFFFF;
  ltr(SEG_TSS << 3);
  lcr3(V2P(p->pgdir)); // switch to process's address space
  popcli();
}

// Load the initcode into address 0 of pgdir.
// sz must be less than a page.
void inituvm(pde_t *pgdir, char *init, uint sz)
{
  char *mem;

  if (sz >= PGSIZE)
    panic("inituvm: more than a page");
  mem = kalloc();
  memset(mem, 0, PGSIZE);
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W | PTE_U);
  memmove(mem, init, sz);
}

// Load a program segment into pgdir.  addr must be page-aligned
// and the pages from addr to addr+sz must already be mapped.
int loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz)
{
  uint i, pa, n;
  pte_t *pte;

  if ((uint)addr % PGSIZE != 0)
    panic("loaduvm: addr must be page aligned");
  for (i = 0; i < sz; i += PGSIZE)
  {
    if ((pte = walkpgdir(pgdir, addr + i, 0)) == 0)
      panic("loaduvm: address should exist");
    pa = PTE_ADDR(*pte);
    if (sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, P2V(pa), offset + i, n) != n)
      return -1;
  }
  return 0;
}

// Allocate page tables and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
int allocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
  char *mem;
  uint a;

  if (newsz >= KERNBASE)
    return 0;
  if (newsz < oldsz)
    return oldsz;

  a = PGROUNDUP(oldsz);
  for (; a < newsz; a += PGSIZE)
  {
    mem = kalloc();
    if (mem == 0)
    {
      cprintf("allocuvm out of memory\n");
      deallocuvm(pgdir, newsz, oldsz);
      return 0;
    }
    memset(mem, 0, PGSIZE);
    if (mappages(pgdir, (char *)a, PGSIZE, V2P(mem), PTE_W | PTE_U) < 0)
    {
      cprintf("allocuvm out of memory (2)\n");
      deallocuvm(pgdir, newsz, oldsz);
      kfree(mem);
      return 0;
    }
  }
  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
  pte_t *pte;
  uint a, pa;

  if (newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
  for (; a < oldsz; a += PGSIZE)
  {
    pte = walkpgdir(pgdir, (char *)a, 0);
    if (!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
    else if ((*pte & PTE_P) != 0)
    {
      pa = PTE_ADDR(*pte);
      if (pa == 0)
        panic("kfree");
      char *v = P2V(pa);
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
}

// Free a page table and all the physical memory pages
// in the user part.
void freevm(pde_t *pgdir)
{
  uint i;

  if (pgdir == 0)
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for (i = 0; i < NPDENTRIES; i++)
  {
    if (pgdir[i] & PTE_P)
    {
      char *v = P2V(PTE_ADDR(pgdir[i]));
      kfree(v);
    }
  }
  kfree((char *)pgdir);
}

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void clearpteu(pde_t *pgdir, char *uva)
{
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if (pte == 0)
    panic("clearpteu");
  *pte &= ~PTE_U;
}

// Given a parent process's page table, create a copy
// of it for a child.
pde_t *
copyuvm(pde_t *pgdir, uint sz)
{
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if ((d = setupkvm()) == 0)
    return 0;
  for (i = 0; i < sz; i += PGSIZE)
  {
    if ((pte = walkpgdir(pgdir, (void *)i, 0)) == 0)
      panic("copyuvm: pte should exist");
    if (!(*pte & PTE_P))
      continue;
    // panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto bad;
    memmove(mem, (char *)P2V(pa), PGSIZE);
    if (mappages(d, (void *)i, PGSIZE, V2P(mem), flags) < 0)
    {
      kfree(mem);
      goto bad;
    }
  }
  return d;

bad:
  freevm(d);
  return 0;
}

// PAGEBREAK!
//  Map user virtual address to kernel address.
char *
uva2ka(pde_t *pgdir, char *uva)
{
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if ((*pte & PTE_P) == 0)
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  return (char *)P2V(PTE_ADDR(*pte));
}

// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int copyout(pde_t *pgdir, uint va, void *p, uint len)
{
  char *buf, *pa0;
  uint n, va0;

  buf = (char *)p;
  while (len > 0)
  {
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char *)va0);
    if (pa0 == 0)
      return -1;
    n = PGSIZE - (va - va0);
    if (n > len)
      n = len;
    memmove(pa0 + (va - va0), buf, n);
    len -= n;
    buf += n;
    va = va0 + PGSIZE;
  }
  return 0;
}

void flush_tlb()
{
  switchuvm(myproc());
}

void mmap_table_init()
{
  initlock(&mmap_table.lock, "mmap_table");
}

struct mmap_area *find_mmap(void *ptr)
{
  acquire(&mmap_table.lock);
  for (int i = 0; i < MAP_AREA_NR_PER_SYSTEM; i++)
  {
    if (!mmap_table.areas[i].user_nr)
      continue;
    if (mmap_table.areas[i].ptr != ptr)
      continue;
    release(&mmap_table.lock);
    return &mmap_table.areas[i];
  }
  release(&mmap_table.lock);
  return 0;
}
void dealloc_mmap(pde_t *pgdir, struct mmap_area *area)
{
  acquire(&mmap_table.lock);
  if (!area->user_nr)
  {
    release(&mmap_table.lock);
    return;
  }
  struct mmap_area **proc_area = 0;
  struct mmap_area **proc_areas = myproc()->mmap_areas;
  for (int i = 0; i < MAP_AREA_NR_PER_PROCESS; i++)
  {
    if (*(proc_areas + i) == area)
    {
      proc_area = proc_areas + i;
      break;
    }
  }
  if (!proc_area)
  {
    release(&mmap_table.lock);
    return;
  }
  *proc_area = 0;
  --area->user_nr;
  uint uadr_begin = (uint)area->ptr;
  uint uadr_end = uadr_begin + area->len;
  uint base_offset = area->offset;
  struct file *f = area->file;

  release(&mmap_table.lock);
  pte_t *pte;
  uint padr;
  uint foff = f->off;
  for (uint uadr = uadr_begin; uadr < uadr_end; uadr += PGSIZE)
  {
    pte = walkpgdir(pgdir, (char *)uadr, 0);
    if (!pte)
      continue;
    if (!(PTE_FLAGS(*pte) & PTE_P))
      continue;
    padr = PTE_ADDR(*pte);
    if (PTE_FLAGS(*pte) & PTE_D)
    {
      f->off = base_offset + uadr - uadr_begin;
      if (!filewrite(f, (char *)uadr, uadr + PGSIZE > uadr_end ? uadr_end % PGSIZE : PGSIZE))
        panic("failed to write back");
    }
    if (!padr)
      panic("kfree");
    char *v = P2V(padr);
    kfree(v);
    *pte = 0;
  }
  f->off = foff;
  fileclose(f);
}
int is_file_equal(struct file *lhs, struct file *rhs)
{
  if (lhs == rhs)
    return 1;
  if (lhs->type == FD_INODE && rhs->type == FD_INODE && lhs->ip->inum && rhs->ip->inum)
    return 1;
  if (lhs->type == FD_PIPE && rhs->type == FD_PIPE && lhs->pipe && rhs->pipe)
    return 1;
  if (lhs->type == FD_NONE && rhs->type == FD_NONE)
    return 1;
  return 0;
}
struct mmap_area *alloc_mmap(struct file *f, int offset, int len, int flags)
{
  struct mmap_area *area = 0;
  struct mmap_area **proc_area = 0;
  struct mmap_area **proc_areas = myproc()->mmap_areas;
  int len_raw = len;
  len = PGROUNDUP(len);
  if (len == 0 || len % PGSIZE > 0)
    return 0;

  acquire(&mmap_table.lock);
  for (int i = 0; i < MAP_AREA_NR_PER_PROCESS; i++)
  {
    if (!*(proc_areas + i))
      continue;
    if (is_file_equal((*(proc_areas + i))->file, f))
    {
      release(&mmap_table.lock);
      return 0;
    }
  }
  for (int i = 0; i < MAP_AREA_NR_PER_PROCESS; i++)
  {
    if (*(proc_areas + i))
      continue;
    proc_area = proc_areas + i;
    break;
  }
  if (!proc_area)
  {
    release(&mmap_table.lock);
    return 0;
  }
  for (int i = 0; i < MAP_AREA_NR_PER_SYSTEM; i++)
  {
    if (mmap_table.areas[i].user_nr && is_file_equal(f, mmap_table.areas[i].file))
    {
      area = &mmap_table.areas[i];
      *proc_area = area;
      ++area->user_nr;
      release(&mmap_table.lock);
      filedup(f);
      return area;
    }
    if (mmap_table.areas[i].user_nr)
      continue;
    area = &mmap_table.areas[i];
  }
  if (!area)
  {
    release(&mmap_table.lock);
    return 0;
  }

  area->ptr = 0;
  void *ub, *lb;
  int found;
  for (int i = 0; i < MAP_AREA_NR_PER_SYSTEM + 1; i++)
  {
    if (i == MAP_AREA_NR_PER_SYSTEM)
      ub = (void *)KERNBASE;
    else if (mmap_table.areas[i].user_nr)
      ub = mmap_table.areas[i].ptr;
    else
      continue;
    lb = ub - len;
    found = 1;
    for (int j = 0; j < MAP_AREA_NR_PER_SYSTEM; j++)
    {
      if (i == j)
        continue;
      if (!mmap_table.areas[j].user_nr)
        continue;
      if (ub <= mmap_table.areas[j].ptr || lb >= mmap_table.areas[j].ptr + mmap_table.areas[j].len)
        continue;
      found = 0;
      break;
    }
    if (!found)
      continue;
    area->ptr = lb;
  }

  if (!area->ptr)
  {
    release(&mmap_table.lock);
    return 0;
  }
  ++area->user_nr;
  area->file = f;
  area->len = len;
  area->len_raw = len_raw;
  area->offset = offset;
  area->flags = flags;
  *proc_area = area;
  release(&mmap_table.lock);
  filedup(f);
  return area;
}
int load_mmap(uint uadr, struct mmap_area *area)
{
  uint foff = area->file->off;
  area->file->off = area->offset + uadr - (uint)area->ptr;
  int read_count = fileread(area->file, (char *)uadr, PGSIZE);
  area->file->off = foff;
  if (read_count < 0)
    return 0;
  return 1;
}
void protect_mmap(pde_t *pgdir, uint uadr, struct mmap_area *area)
{
  pte_t *pte = walkpgdir(pgdir, (char *)uadr, 0);
  int flags = PTE_U | PTE_P;
  if (area->flags & MAP_PROT_WRITE)
    flags = flags | PTE_W;
  *pte = PTE_ADDR(*pte) | flags;
}
int serve_mmap_page(uint vadr, int is_write)
{
  struct mmap_area *area;
  for (int i = 0; i < MAP_AREA_NR_PER_SYSTEM; i++)
  {
    area = &mmap_table.areas[i];
    if (!area->user_nr)
      continue;
    if ((void *)vadr < area->ptr)
      continue;
    if (area->ptr + area->len <= (void *)vadr)
      continue;
    if (is_write && !(area->flags & MAP_PROT_WRITE))
      break;
    if (!is_write && !(area->flags & MAP_PROT_READ))
      break;
    uint aligned_adr = vadr & ~(PGSIZE - 1);
    char *mem = kalloc();
    if (mem == 0)
      return 0;
    if (mappages(myproc()->pgdir, (char *)aligned_adr, PGSIZE, V2P(mem), PTE_W) < 0)
      return 0;
    flush_tlb();

    if (!load_mmap(aligned_adr, area))
      break;
    protect_mmap(myproc()->pgdir, aligned_adr, area);
    flush_tlb();

    return 1;
  }
  return 0;
}
int serve_stack_page(uint vadr)
{
  uint stack_upper_bound = myproc()->ustack_start;
  uint stack_lower_bound = stack_upper_bound - PGSIZE * 4;
  uint touched_page = PGROUNDDOWN(vadr);

  if (vadr < myproc()->executable_info.sz)
    return 0;
  if (touched_page < stack_lower_bound)
  {
    myproc()->killed = 1;
    cprintf("killed: stack overflow\n");
    return 1;
  }
  if (touched_page >= stack_upper_bound)
    return 0;
  if (allocuvm(myproc()->pgdir, touched_page, touched_page + PGSIZE) == 0)
    return 0;
  flush_tlb();
  return 1;
}
int serve_heap_page(uint vadr)
{
  uint heap_lower_bound = myproc()->ustack_start;
  uint heap_upper_bound = myproc()->sz;
  uint touched_page = PGROUNDDOWN(vadr);
  if (touched_page < heap_lower_bound)
    return 0;
  if (touched_page >= heap_upper_bound)
    return 0;
  if (allocuvm(myproc()->pgdir, touched_page, touched_page + PGSIZE) == 0)
    return 0;
  flush_tlb();
  return 1;
}
int serve_executable_page(uint vadr)
{
  struct executable_info *info = &myproc()->executable_info;
  if (vadr >= info->sz)
    return 0;

  int i, off;
  struct proghdr ph;
  pde_t *pgdir = myproc()->pgdir;
  uint sz = 0;

  begin_op();
  ilock(info->ip);
  for (i = 0, off = info->phoff; i < info->phnum; i++, off += sizeof(ph))
  {

    if (readi(info->ip, (char *)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if (ph.type != ELF_PROG_LOAD)
      continue;
    if ((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
      goto bad;
    if (loaduvm(pgdir, (char *)ph.vaddr, info->ip, ph.off, ph.filesz) < 0)
      goto bad;
    // cprintf("section w/ %x is loaded into [%p,%p)\n", ph.flags, ph.vaddr, ph.vaddr + ph.memsz);
  }
  iunlockput(info->ip);
  end_op();
  flush_tlb();
  return 1;
bad:
  iunlockput(info->ip);
  end_op();
  return 0;
}
int serve_page(uint vadr, int is_write)
{
  if (serve_mmap_page(vadr, is_write))
    return 1;
  if (serve_stack_page(vadr))
    return 1;
  if (serve_heap_page(vadr))
    return 1;
  if (serve_executable_page(vadr))
    return 1;

  return 0;
}
// PAGEBREAK!
//  Blank page.
// PAGEBREAK!
//  Blank page.
// PAGEBREAK!
//  Blank page.
