#include "param.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

void print_frees(char *desc)
{
	static int nr_frees = -1;
	static int prev_nr_frees = -1;
	if (nr_frees == -1)
		nr_frees = frees();
	if (!desc)
		return;
	prev_nr_frees = nr_frees;
	nr_frees = frees();
	printf(1, "delta frees after %s: %d\n", desc, nr_frees - prev_nr_frees);
}
int main(void)
{
	print_frees(0);
	for (int i = 0; i < 10; i++)
	{
		char *arr = sbrk(2048);
		print_frees("sbrk");
		arr[0] = 0;
		print_frees("touch");
	}
	exit();
}
